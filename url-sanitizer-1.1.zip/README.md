# url-sanitizer
A simple chrome extension that strip web page's tracking parameters.

## Verified sites:
- Youtube
- Bilibili 